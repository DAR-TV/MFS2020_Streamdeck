Le package Stream.Deck.Icon.Pack.v3 vient d'ici: 

https://github.com/hey8you/Stream-Deck-and-MSFS-2020/releases